#!/usr/bin/env python3
# скрипт игры "простое ли число?"

from brain_games.games.brains_prime_game import play_prime_game


def main():
    play_prime_game()


if __name__ == '__main__':
    main()
