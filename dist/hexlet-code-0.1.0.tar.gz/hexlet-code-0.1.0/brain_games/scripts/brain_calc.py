#!/usr/bin/env python3
import brain_games.games.brains_calc_game


def main():
    brain_games.games.brains_calc_game.play_calc_game()


if __name__ == '__main__':
    main()
