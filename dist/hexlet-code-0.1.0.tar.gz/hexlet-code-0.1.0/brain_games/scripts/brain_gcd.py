#!/usr/bin/env python3
# скрипт игры нахождения наибольшего общего делителя

from brain_games.games.brains_gcd_game import play_gcd_game


def main():
    play_gcd_game()


if __name__ == '__main__':
    main()
