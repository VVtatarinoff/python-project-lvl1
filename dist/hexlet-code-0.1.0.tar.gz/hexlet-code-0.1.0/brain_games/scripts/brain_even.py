#!/usr/bin/env python3
import brain_games.brains_even_game


def main():
    brain_games.brains_even_game.play_even_game()


if __name__ == '__main__':
    main()
