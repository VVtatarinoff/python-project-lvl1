#!/usr/bin/env python3
# скрипт игры арифметическая прогрессия

from brain_games.games.brains_progr_game import play_progr_game


def main():
    play_progr_game()


if __name__ == '__main__':
    main()
